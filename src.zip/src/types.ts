export type MenuCategoryId = 'all' | 'biriyani' | 'starters' | 'curries' | 'breads';

export interface MenuItem {
  id: string;
  category: 'biriyani' | 'starters' | 'curries' | 'breads';
  title: string;
  subtitle?: string;
  description: string;
  badge: string;
  isVeg: boolean;
  imageUrl: string;
  searchKeywords: string;
}

export interface MenuCategory {
  id: 'biriyani' | 'starters' | 'curries' | 'breads';
  title: string;
  description: string;
  tag: string;
}
