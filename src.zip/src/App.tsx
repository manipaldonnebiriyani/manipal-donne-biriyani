import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { WhyDonne } from './components/WhyDonne';
import { VisitSection } from './components/VisitSection';
import { Footer } from './components/Footer';
import { DishModal } from './components/DishModal';
import { MenuItem } from './types';
import { Phone } from 'lucide-react';

export default function App() {
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);

  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0c0a] text-[#ede7de] flex flex-col selection:bg-[#f3b43f] selection:text-black">
      {/* Top Navigation */}
      <Navbar onNavigate={handleNavigate} />

      {/* Hero Banner */}
      <Hero onExploreMenu={() => handleNavigate('menu')} />

      {/* The Kitchen Board / Menu Section */}
      <MenuSection onSelectItem={(dish) => setSelectedDish(dish)} />

      {/* Why Donne Matters Story Section */}
      <WhyDonne onBrowseMenu={() => handleNavigate('menu')} />

      {/* Plan Your Visit & Location */}
      <VisitSection />

      {/* Site Footer */}
      <Footer />

      {/* Dish Detail Inspection Modal */}
      <DishModal item={selectedDish} onClose={() => setSelectedDish(null)} />

      {/* Floating Call Button for quick takeaway access on smaller viewports */}
      <div className="fixed bottom-6 right-6 z-40 md:hidden">
        <a
          href="tel:+918296821532"
          className="flex items-center gap-2 px-4 py-3 rounded-full bg-[#f3b43f] text-black font-semibold text-xs shadow-2xl hover:bg-[#e4a42e] transition-transform active:scale-95"
          aria-label="Call restaurant"
        >
          <Phone className="w-4 h-4 fill-current" />
          <span>Call Hotel</span>
        </a>
      </div>
    </div>
  );
}
