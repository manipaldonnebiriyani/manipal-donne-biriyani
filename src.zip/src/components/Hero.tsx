import React, { useState, useEffect } from 'react';
import { Phone, Clock, ArrowRight, Star } from 'lucide-react';
import donneLeafImage from '../assets/images/donne_biriyani_leaf_1789753858824.jpg';
import donneCircleImage from '../assets/images/donne_biriyani_circle_1789753879982.jpg';
import donneTableImage from '../assets/images/donne_biriyani_table_1789753808731.jpg';

interface HeroProps {
  onExploreMenu: () => void;
}

const BACKGROUND_IMAGES = [
  {
    url: donneLeafImage,
    label: 'Naati Donne Biriyani & Kebabs',
  },
  {
    url: donneCircleImage,
    label: 'Authentic 6-Variety Feast Platter',
  },
  {
    url: donneTableImage,
    label: 'Seeraga Samba Dum Donne Biriyani',
  },
];

export const Hero: React.FC<HeroProps> = ({ onExploreMenu }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Automatically cycle through background images every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % BACKGROUND_IMAGES.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <section
      className="relative pt-12 pb-16 md:pt-24 md:pb-28 overflow-hidden border-b border-[#211e19]"
    >
      {/* Sliding Background Images Layer (cycles every 5 seconds) */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {BACKGROUND_IMAGES.map((img, idx) => {
          const isActive = idx === currentImageIndex;
          const isPrev =
            idx === (currentImageIndex - 1 + BACKGROUND_IMAGES.length) % BACKGROUND_IMAGES.length;

          return (
            <div
              key={img.url}
              className={`absolute inset-0 bg-cover bg-right md:bg-[center_right_15%] bg-no-repeat transition-all duration-1000 ease-in-out transform ${
                isActive
                  ? 'opacity-100 translate-x-0 scale-100'
                  : isPrev
                  ? 'opacity-0 -translate-x-12 scale-105'
                  : 'opacity-0 translate-x-12 scale-105'
              }`}
              style={{
                backgroundImage: `url("${img.url}")`,
              }}
            />
          );
        })}
      </div>

      {/* Atmospheric overlays: Soft gradient on the left to blend text harmoniously while leaving the dishes strikingly visible */}
      <div className="absolute inset-0 z-[1] bg-gradient-to-r from-[#0d0c0a] via-[#0d0c0a]/80 to-transparent sm:w-3/4 md:w-2/3 pointer-events-none" />
      <div className="absolute inset-0 z-[1] bg-gradient-to-t from-[#0d0c0a] via-transparent to-[#0d0c0a]/50 pointer-events-none" />
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-[#0e0d0b]/70 via-transparent to-[#0d0c0a] pointer-events-none" />

      {/* Warm spice ambient glow behind the title and biriyani */}
      <div className="absolute left-10 top-1/3 w-[450px] h-[350px] bg-[#f3b43f]/10 rounded-full blur-3xl pointer-events-none z-[1]" />
      <div className="absolute right-8 top-1/2 -translate-y-1/2 w-[520px] h-[520px] bg-[#f3b43f]/15 rounded-full blur-[100px] pointer-events-none z-[1]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl">
          {/* Status Indicator Pill */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1b1914]/90 backdrop-blur-md border border-[#383227] text-[11px] font-semibold tracking-wider text-[#d4cdbf] mb-6 shadow-md">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400/50" />
            <span>OPEN TUE–SUN</span>
            <span className="text-[#645c50]">•</span>
            <span className="text-[#cfc7b9]">MANIPAL, KARNATAKA</span>
          </div>

          {/* Hero Headline - Blended seamlessly with typographic depth */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-6xl font-serif font-bold tracking-tight text-white leading-[1.12] mb-5 drop-shadow-md">
            Authentic Naati Donne Biriyani{' '}
            <span className="bg-gradient-to-r from-[#f3b43f] via-[#ffd680] to-[#f3b43f] bg-clip-text text-transparent drop-shadow-[0_2px_12px_rgba(243,180,63,0.3)]">
              in Manipal.
            </span>
          </h1>

          {/* Subheading Description with subtle backdrop scrim for crisp legibility */}
          <p className="text-base sm:text-lg text-[#ded8cb] leading-relaxed max-w-2xl mb-6 drop-shadow-sm font-normal">
            Fragrant seeraga samba rice, hand-ground green masala, and generous portions served in traditional areca-leaf donnes.
          </p>

          {/* Highlights Badges */}
          <div className="flex flex-wrap items-center gap-2.5 mb-8">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#171512]/85 backdrop-blur-md border border-[#383126] text-xs text-[#e4ded4] shadow-sm">
              <Star className="w-3.5 h-3.5 text-[#f3b43f] fill-[#f3b43f]" />
              <span className="font-medium">4.5 rated on Google</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#171512]/85 backdrop-blur-md border border-[#383126] text-xs text-[#e4ded4] shadow-sm">
              <span className="text-emerald-400">🍃</span>
              <span className="font-medium">Served in natural donnes</span>
            </span>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center gap-4 mb-6">
            <a
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#f3b43f] hover:bg-[#e4a42e] text-black font-bold text-sm transition-all shadow-xl shadow-[#f3b43f]/25 active:scale-98"
              href="tel:+918296821532"
            >
              <Phone className="w-4 h-4 fill-current" />
              <span>Call +91 82968 21532</span>
            </a>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <button
              onClick={onExploreMenu}
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#f3b43f] hover:text-[#ffd680] hover:underline underline-offset-4 cursor-pointer group transition-colors"
            >
              <span>View the full menu</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            {/* Slide Navigation Dots (Every 5 seconds) */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#151310]/80 border border-[#332b21] backdrop-blur-md">
              <span className="text-[10px] text-[#9a9182] font-medium tracking-wider uppercase mr-1 hidden sm:inline">
                {BACKGROUND_IMAGES[currentImageIndex].label}
              </span>
              <div className="flex items-center gap-1.5">
                {BACKGROUND_IMAGES.map((img, idx) => (
                  <button
                    key={img.label}
                    onClick={() => setCurrentImageIndex(idx)}
                    className={`h-1.5 rounded-full transition-all duration-500 cursor-pointer ${
                      idx === currentImageIndex
                        ? 'w-6 bg-[#f3b43f]'
                        : 'w-2 bg-white/25 hover:bg-white/50'
                    }`}
                    title={`Slide to ${img.label}`}
                    aria-label={`Slide to ${img.label}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Operating Hours & Pricing Metadata Ribbon */}
      <div className="relative z-20 mt-12 border-t border-[#383126] bg-[#12100d]/95 backdrop-blur-md py-4 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 text-sm">
            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-[#1c1914] border border-[#3d362a] shadow-sm">
              <Clock className="w-4 h-4 text-[#f3b43f]" />
              <span className="text-white font-bold tracking-wide">Lunch 12–4 PM</span>
            </span>
            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-[#1c1914] border border-[#3d362a] shadow-sm">
              <Clock className="w-4 h-4 text-[#f3b43f]" />
              <span className="text-white font-bold tracking-wide">Dinner 7–11 PM</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1c1914] border border-[#3d362a] shadow-sm">
              <span className="w-2 h-2 rounded-full bg-red-400" />
              <span className="text-white font-semibold">Monday closed</span>
            </span>
          </div>
          <div className="inline-flex items-center px-3.5 py-1.5 rounded-lg bg-[#241e15] border border-[#443722] font-bold tracking-wider text-[#f3b43f] uppercase text-xs shadow-sm self-start sm:self-auto">
            ₹300–₹350 FOR TWO
          </div>
        </div>
      </div>
    </section>
  );
};
